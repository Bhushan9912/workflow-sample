<?php
namespace Config;

// Create a new instance of our RouteCollection class.
$routes = Services::routes();

// Load the system's routing file first, so that the app and ENVIRONMENT
// can override as needed.
if (file_exists(SYSTEMPATH . 'Config/Routes.php')) {
    require SYSTEMPATH . 'Config/Routes.php';
}

/*
 * --------------------------------------------------------------------
 * Router Setup
 * --------------------------------------------------------------------
 */
$routes->setDefaultNamespace('App\Controllers');
//$routes->setDefaultController('Home');
//$routes->setDefaultMethod('index');
$routes->setTranslateURIDashes(false);
$routes->set404Override();
$routes->setAutoRoute(true);

/*
 * --------------------------------------------------------------------
 * Route Definitions
 * --------------------------------------------------------------------
 */

// We get a performance increase by specifying the default
// route since we don't have to scan directories.
$routes->get('/', 'Home::index');
$routes->get('/reg', 'Register::index');
$routes->get('/logout', 'Home::logout');
//users routes 
$routes->get('/manage_users', 'Users::index');
$routes->get('/dashboard', 'Home::dashboard');

//product category
$routes->get('/manage_category',        'ProductCategory::index');
$routes->get('/add_category',           'ProductCategory::add');
$routes->post('/category_save',         'ProductCategory::store');
$routes->get('/edit_category/(:num)',   'ProductCategory::edit/$1');
$routes->post('/category_update',       'ProductCategory::update');
$routes->get('/category_delete/(:num)', 'ProductCategory::delete/$1');
$routes->post('/category_status',       'ProductCategory::status');

//product 
$routes->get('/manage_product',        'Product::index');
$routes->get('/add_product',           'Product::add');
$routes->post('/product_save',         'Product::store');
$routes->get('/edit_product/(:num)',   'Product::edit/$1');

$routes->post('/product_update',       'Product::update');
//$routes->get('/product_delete/(:num)', 'Product::delete/$1');
$routes->post('/product_delete',         'Product::delete');
$routes->post('/product_status',       'Product::status');
$routes->post('/product_details',      'Product::detail');
$routes->get('/product_pdf/(:num)',    'PdfController::index/$1');
$routes->get('/product_export',        'Product::export');


//Main Category  
$routes->get('/manage_main_category',        'Category::index');
$routes->get('/add_main_category',           'Category::add');
$routes->post('/main_category_save',         'Category::store');
$routes->get('/edit_main_category/(:num)',   'Category::edit/$1');
$routes->post('/main_category_update',       'Category::update');
$routes->get('/main_category_delete/(:num)', 'Category::delete/$1');
$routes->post('/main_category_status',       'Category::status');

//Main Category  
$routes->get('/from_control_add',           'Category::from_control_add');
$routes->post('/from_control_save',         'Category::from_control_save');
//Smtp
$routes->get('/send_mail',                  'SendMail::index');
$routes->post('/sendmail',         'SendMail::send_mail');
$routes->post('/sendmail',         'SendMail::send_mail');
$routes->post('/sendmail',         'SendMail::send_mail');
$routes->post('import-csv', 'Product::importCsvToDb');

//payment gateway Routes   
//$routes->get('/product_list',      'Product::product_list');

//RazorpayController routes
$routes->get('product_list', 'RazorpayController::payWithRazorpay');
$routes->get('transaction', 'RazorpayController::transaction');
// Post Route For making Payment Request
$routes->post('payment', 'RazorpayController::processPayment');
//
$routes->post("product_store", "ProductApi::product_store");
$routes->post("product_update_api", "ProductApi::product_update");


//Rule Engin

//Operator
$routes->get('/manage_operator',        'Operator::index');
$routes->get('/add_operator',           'Operator::add');
$routes->post('/operator_save',         'Operator::store');
$routes->get('/operator_delete/(:num)', 'Operator::delete/$1');
//Action
$routes->get('/manage_action',        'Action::index');
$routes->get('/add_action',           'Action::add');
$routes->post('/action_save',         'Action::store');
$routes->post('/action_delete',       'Action::delete');
$routes->post('/action_details',      'Action::detail');
$routes->post('/getParameter',        'Action::getParameter');
//work flow
$routes->get('/manage_workflow',        'Workflow::index');
$routes->get('/add_workflow',           'Workflow::add');
$routes->post('/workflow_save',         'Workflow::store');
$routes->post('/workflow_details',      'Workflow::detail');
$routes->post('/workflow_delete',       'Workflow::delete');
/* $routes->get('/edit_workflow/(:num)',   'Workflow::edit/$1');
$routes->post('/workflow_update',       'Workflow::update');

$routes->post('/workflow_status',       'Workflow::status');

$routes->post('/workflow_on_save',      'Workflow::on_save_changes');
 */




//Rest Api


/*
 * --------------------------------------------------------------------
 * Additional Routing
 * --------------------------------------------------------------------
 *
 * There will often be times that you need additional routing and you
 * need it to be able to override any defaults in this file. Environment
 * based routes is one such time. require() additional route files here
 * to make that happen.
 *
 * You will have access to the $routes object within that file without
 * needing to reload it.
 */
if (file_exists(APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php')) {
    require APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php';
}
