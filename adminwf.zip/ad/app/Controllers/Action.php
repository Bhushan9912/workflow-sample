<?php
namespace App\Controllers;
use CodeIgniter\Controller;
use App\Models\ActionModel;
use App\Models\ActionDetailsModel;

class Action extends BaseController
{
    private $db;
    Public function __construct()
    {  
        $this->db = db_connect();
        $this->session = session();
        $this->title = 'Action'; 
        $this->url_slug = 'action'; 
        $this->folder_path = 'action/'; 

    }

    public function index()
    {  
       $data=[]; 
       $action           = $this->db->table("action");
       $action_list      = $action->get()->getResult();
       $data['action']   = $action_list;
       $data['title']    = $this->title;
       $data['url_slug'] = $this->url_slug;

       return view($this->folder_path.'index',$data);
    }

    public function add()
    {  
      
       $data=[]; 
       $data['title']    = $this->title." Add";
       $data['url_slug']    = $this->url_slug;
       return view($this->folder_path.'add',$data);
    }

    public function store()
    {
        helper(['form','url']);
        $validation =   \Config\Services::validation();
        $check      =   $this->validate([
                'action_name'     =>'required',
        ]);

        if(!$check)
        {
             $msg = $this->validator->listErrors();
             $this->session->setFlashdata('error','Please enter all fields.');
             return redirect()->to('add_'.$this->url_slug); 
        }
        else
        { 
            $failed = 0 ;
            $model = new ActionModel();
            $data  = [
                       'action_name'     => $this->request->getvar('action_name'),
                       'expression'      => $this->request->getvar('expression'),
                     ];
            $save  = $model->insert($data);        
            if($save)
            {      
                $action_id = $model->getInsertID();;
                $parameter_model = new ActionDetailsModel();
                $rowcnt  = $this->request->getvar('row_cnt'); //3
                $item_data =[];
                for ($i=1;$i<=$rowcnt;$i++) 
                {
                 
                    if(!empty($this->request->getvar('parameter_name'.$i)))
                    {
                       
                        $data1  = [
                            'action_id'  => $action_id,
                            'parameter_name'     => $this->request->getvar('parameter_name'.$i),
                          ];
                        $parameter_save  = $parameter_model->insert($data1); 
                        if(empty($parameter_save))
                        {
                             $failed++;
                        }
                    }

                   

                }
            }
            
            if($failed==0)
            {
                $this->session->setFlashdata('success', 'Action added successfully');
                return redirect()->to('manage_'.$this->url_slug); 
            }
            else
            {
                $this->session->setFlashdata('error', 'Something is wrong.');
                return redirect()->to('manage_'.$this->url_slug); 
            }
        }  
    }

    

    public function delete()
    {
        $id= $this->request->getvar('pid');
        $model = new ActionModel();
        $action_details = new ActionDetailsModel();
  
        if($model->find($id))
        {
           $model->where('action_id',$id)->delete();
           $action_details->where('action_id',$id)->delete();
           $this->session->setFlashdata('success', 'Action Deleted successfully');
           return redirect()->to('manage_'.$this->url_slug); 
        }
        else
        {
            $this->session->setFlashdata('error', 'Something is wrong.');
            return redirect()->to('manage_'.$this->url_slug); 
        }
        
        return redirect()->route('/');
  
     }

    public function detail()
    {
        
       $id= $this->request->getvar('id');

       $data=[]; 
       $model = new ActionModel();
       $action_details = new ActionDetailsModel();
 
       
       $action  = $model->where('action_id',$id)->first();
       $action_list = $action_details->where('action_id',$id)->get()->getResult();
       
       $data['action']   = $action;
       $data['action_list']     = $action_list;
       $data['title']    = $this->title." Details";
       return view($this->folder_path.'view',$data);
    } 

    public function getParameter()
    {
        
        $action_id = $this->request->getvar('action_id');
        $cnt = $this->request->getvar('cnt');
 
        /*$listq = $this->db->table("action_details as a");
        $listq->select('a.*, b.action_name,b.expression');
        $listq->join('action as b', 'a.action_id = b.action_id');
        $listq->whereIn('a.action_id',$action_id);
        $listr = $listq->get()->getResult(); */
        $model = new ActionModel();
        $action_details = new ActionDetailsModel();
  
        $listr  = $model->whereIn('action_id',$action_id)->get()->getResult();
        $html = '';
        foreach($listr as $listrow){
            $html .= '<div id="act'.$listrow->action_id.'"><hr/><h6 style="font-weight: 500 !important;">'.$listrow->action_name.'</h6>';

            $listr2 = $action_details->where('action_id',$listrow->action_id)->get()->getResult();
            foreach($listr2 as $listrow2){
                $html.= $listrow2->parameter_name.': <input type="text" name="'.$listrow2->parameter_name.$cnt.'" class="forn-control" data-act="'.$listrow->expression.'" onchange="calcExp('.$cnt.')"><br/>';
            }
            $html.='</div>';
       }

       return implode(',',$action_id)."{#}".$html;
      
       
       


    } 

   
}
