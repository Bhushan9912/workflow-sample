<?php
namespace App\Controllers;
use CodeIgniter\Controller;
use App\Models\RegisterModel;
class Users extends BaseController
{
    Public function __construct()
    {  
        $this->title = 'User'; 
        $this->folder_path = 'user/'; 
    }

    public function index()
    {  
       $data=[]; 
       $model = new  RegisterModel();
       $user_list = $model->findAll();
       $data['userlist'] = $user_list;
       $data['title']    = $this->title;
       return view($this->folder_path.'index',$data);
    }

 

}
