<?php
namespace App\Controllers;
use CodeIgniter\Controller;
use App\Models\WorkflowModel;
use App\Models\ActionModel;
use App\Models\ActionDetailsModel;

class Workflow extends BaseController
{
    private $db;
    Public function __construct()
    {  
        $this->db = db_connect();
        $this->session = session();
        $this->title = 'WorkFlow'; 
        $this->url_slug = 'workflow'; 
        $this->folder_path = 'workflow/'; 
     
    }
   
    public function index()
    {  
       $data=[]; 
       $workflow = $this->db->table("workflow");
       $workflow_list = $workflow->get()->getResult();
       $data['workflow'] = $workflow_list;
       $data['title']    = $this->title;
       $data['url_slug']    = $this->url_slug;

       return view($this->folder_path.'index',$data);
    }

    public function add()
    {  
      
       $data=[];
       $action_model = new  ActionModel();
       $action_list = $action_model->where('active','y')->findAll();

       $data['action_list']    = $action_list;
   
       $data['title']          = $this->title." Add";
       $data['url_slug']       = $this->url_slug;
       return view($this->folder_path.'add',$data);
    }

    public function store()
    {
   
        $workflow_array = [];
        $workflow_array['workflow_name']        =  $this->request->getvar('work_flow_name');
        $workflow_array['grievance_type']       =  $this->request->getvar('grievance_type');
        $workflow_array['grievance_sub_type']   =  $this->request->getvar('grievance_sub_type');
        $workflow_array['workflow_tat']         =  $this->request->getvar('tat');
        $workflow_array['remark']               =  $this->request->getvar('remark');
        $workflow_array['data']                 = [];
        $workflow_array['data']['action']       = $this->append_array($this->request->getPost(),"_","");

       
        $wf_model = new WorkflowModel();
        $arr_data  = [
                        'work_flow_name'       =>  $this->request->getvar('work_flow_name'),
                        'grievance_type'       =>  $this->request->getvar('grievance_type'),
                        'grievance_sub_type'   =>  json_encode($this->request->getvar('grievance_sub_type')),
                        'workflow_tat'         =>  $this->request->getvar('tat'),
                        'remark'               =>  $this->request->getvar('remark'),
                        'workflow_json'        =>  json_encode($workflow_array),
                   ];

      
        $wf_save  = $wf_model->insert($arr_data);  
        if($wf_save)
        {     
            $this->session->setFlashdata('success', 'Work Flow added successfully');
            return redirect()->to('manage_'.$this->url_slug); 
        }
        else
        {
            $this->session->setFlashdata('error', 'Something is wrong.');
            return redirect()->to('manage_'.$this->url_slug); 
        }  
    }
    
    public function append_array($request, $step="", $yn="")
    {
        $rowcnt         = $request['row_count'.$yn.$step];
        $step= $step == '_' ? '' : $step;
        $wfa = [];
        for ($i=1;$i<=$rowcnt;$i++) 
        {
            $j=$yn."_".$i.$step;
            if($step!==''){
                $step = explode('_',$step);
                array_pop($step);
                $step[] = $i;
                $step = implode('_',$step);
                $j = $yn.$step;
            }
            
            if(isset($request['action'.$j]))
            {
                $wfa[$i]['name']   =  $request['action'.$j];
                $wfa[$i]['role']   =  $request['role'.$j];
                $wfa[$i]['tat']    =  $request['task_tat'.$j];
                $wfa[$i]['stage']  =  $request['task_process'.$j];
            }

            if(isset($request['condition'.$j]))
            {
                $wfa[$i]['name']    =  $request['condition'.$j];
                $wfa[$i]['role']    =  $request['condition_role'.$j];
                $wfa[$i]['tat']     =  $request['condition_tat'.$j];
                $wfa[$i]['stage']   =  $request['condition_process'.$j];
                $wfa[$i]['IsTrue']  = [];
                $wfa[$i]['IsFalse']  = [];
                
                $x = $step != '' ? $step : '_'.$i;
                if(isset($request['row_county'.$x.'_1'])){
                    $wfa[$i]['IsTrue']  = $this->append_array($request, $x.'_1','y');
                }
                if(isset($request['row_countn'.$x.'_1'])){
                    $wfa[$i]['IsFalse']  = $this->append_array($request, $x.'_1','n');
                } 
            
            }
            
        }
        return $wfa;
    }
    

    public function delete()
    {
        $id= $this->request->getvar('pid');
        $model = new WorkflowModel();
  
        if($model->find($id)){
            $model->delete($id);
            $this->session->setFlashdata('success', 'WorkFlow Deleted successfully');
            return redirect()->to('manage_'.$this->url_slug); 
        }else{
            $this->session->setFlashdata('error', 'Something is wrong.');
            return redirect()->to('manage_'.$this->url_slug); 
        }
  
        return redirect()->route('/');
  
     }

    public function detail()
    {
        
       $id= $this->request->getvar('id');
       $data=[]; 
       $work_flow_model = new  WorkflowModel();
       $workflow  = $work_flow_model->where('work_flow_id',$id)->first();
       $data['workflow'] = $workflow;
       $data['title']    = $this->title." Details";
       return view($this->folder_path.'view',$data);
    } 

   
}
