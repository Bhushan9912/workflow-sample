<?php 

trait RuleTrait{
    public function list()
    {  
       $data=[]; 
       $workflow = $this->db->table("workflow");
       $workflow_list = $workflow->get()->getResult();
       $data['workflow'] = $workflow_list;
       $data['title']    = $this->title;
       $data['url_slug']    = $this->url_slug;

       return view($this->folder_path.'index',$data);
    }
}


?>