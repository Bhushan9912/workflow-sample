<?php 
namespace App\Models;

use CodeIgniter\Model;

class ActionDetailsModel extends Model
{
    protected $table = 'action_details';
    protected $primaryKey = 'action_detail_id '; 
    protected $allowedFields = ['action_id','parameter_name','active','created_at','created_by'];
}

?>