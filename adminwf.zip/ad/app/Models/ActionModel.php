<?php 
namespace App\Models;

use CodeIgniter\Model;

class ActionModel extends Model
{
    protected $table = 'action';
    protected $primaryKey = 'action_id '; 
    protected $allowedFields = ['action_name','expression','active','created_at','created_by','updated_at','updated_by','deleted_at','deleted_by'];
}

?>