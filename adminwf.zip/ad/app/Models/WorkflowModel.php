<?php 
namespace App\Models;

use CodeIgniter\Model;

class WorkflowModel extends Model
{
    protected $table = 'workflow';
    protected $primaryKey = 'work_flow_id '; 
    protected $allowedFields = ['work_flow_name','grievance_type','grievance_sub_type','workflow_tat','remark','workflow_json','active','created_at','created_by','updated_at','updated_by','deleted_at','deleted_by'];
}


?>