
<?php $this->extend('layouts/master')?>
<?php $this->section('content'); ?>
<style>.table th, .table td{padding: .75rem;}</style>
	<section class="content">
	<div class="container-fluid">
		<div class="row">
		  <div class="col-12">
		  <div class="card card-info">
			  <div class="card-header">
				<h3 class="card-title">Add WorkFlow</h3>
			  </div>
			  <form action="<?php echo site_url($url_slug.'_save');?>" method="post" class="form-horizontal" enctype="multipart/form-data">
			  <?php csrf_field() ?>
				  <div class="card-body">
					  <div class="row">
						<div class="col-8">
							<div class="form-group">
								<label for="product_name">WorkFlow Name</label>
								<input type="textbox" class="form-control" id="work_flow_name" name="work_flow_name" placeholder="Work Flow Name">
							</div> 
						</div>
					  </div>  
					<div class="row">      
					  
					  <div class="col-4">
						<label for=grievance_type">Select Grievance Type</label>
						<select name="grievance_type" id="grievance_type" class="form-control">
							<option value="NULL">-Select Grievance Type-</option>                            
							<option value="Payment Issue">Payment issues</option>                            
							<option value="Cash Card Issue">Cash card issues</option>                            
							<option value="Inclusion request" selected>Inclusion request</option>                            
						</select>
					  </div>
					  <div class="col-4">
						<label for=grievance_sub_type">Select Grievance Sub Type</label>
						<select name="grievance_sub_type[]" id="grievance_sub_type" class="form-control select2" Multiple>
							<option value="NULL">-Select Sub Grievance Type-</option>                            
							<option value="Transient Poor">Transient Poor</option>                            
							<option value="Chronic Poor">Chronic Poor</option>                            
							<option value="Extreme Poor">Extreme Poor</option>                            
						</select>   
					  </div>
					  <div class="col-4">
						<div class="form-group">
						  <label for="tat_name">TAT</label>
						  <input type="textbox" class="form-control" id="tat" name="tat" placeholder="Please Enter TAT">
						</div> 
					  </div>
					 </div>
					<div class="row">
					  <div class="col-12">
					   <div class="form-group">
						  <label for="tat_name">Remark</label>
						  <textarea class="form-control" rows="5" name="remark"></textarea>
					   </div>
					  </div>
					</div>
				  </div>
				  <div class="d-none" id="action">
					 <option value="">-Select-</option>
					 <?php foreach($action_list as $action_value) {?>
					 <option value="<?php echo $action_value['expression']; ?>"><?php echo $action_value['expression']; ?></option> 
					 <?php }?>
				   </div>
				   <div id="processdrp" class="d-none">
					 <option value="PRE INTAKE">PRE INTAKE</option>
					 <option value="INTAKE AND RESPONCE">INTAKE AND RESPONCE</option>
					 <option value="PROCESSING">PROCESSING</option>
					 <option value="RESOLUTION">RESOLUTION</option>
					 <option value="FEEDBACK">FEEDBACK</option>
				   </div>
				   <div id="roledrp" class="d-none">
					 <option value="NHTO/NHTU">NHTO/NHTU</option>
					 <option value="BDMD">BDMU</option>
					 <option value="NPM/RD">NPM/RD</option>
					 <option value="GO">GO</option>
					 <option value="CL/MA/GO/GRDSTAFF">CL/MA/GO/GRDSTAFF</option>
				   </div>
				  <div class="row">
				  <div class="col-12">
				  <table class="table table-bordered " id="rulebox" >
				   <thead>
					 <tr>
					   <th style="padding-top: 0;text-transform: capitalize;padding-bottom: 0;">Method</th>
					   <th style="padding-top: 0;text-transform: capitalize;padding-bottom: 0;">User Role</th>
					   <th style="padding-top: 0;text-transform: capitalize;padding-bottom: 0;">TAT</th>
					   <th style="padding-top: 0;text-transform: capitalize;padding-bottom: 0;">Select Proces</th>
					   <th style="padding: 0px;"></th>
					 </tr>
				   </thead>
				   <tbody>
					
					 
				   </tbody>                 
				 </table>

				 </div>

				  </div>

				<div class="row">
				  <div class="col-12">
					  <button type="button" class="btn btn-info btn-sm addtaskBtn" onclick="addTask()">Add New Task</button>
					  <button type="button" class="btn btn-info btn-sm addactionBtn" onclick="addCondition()">Add New Condition</button>
					  <input type="text" name="row_count_" id="row_count_" readonly value="0">
				  </div>
				</div>      

				<div class="card-footer">
				  <button type="submit" class="btn btn-info float-right ml-2">Add Work Flow</button>
				  <a href="<?php echo site_url('/manage_'.$url_slug)?>" class="btn btn-default float-right">Cancel</a>
				</div>
			  </form>
			</div>
		  </div>
		</div>
	  </div>
	</section>
	<!-- DataTables  & Plugins -->
	<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
	<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<style>
.select2-container--default .select2-selection--multiple .select2-selection__choice {
	background-color: #ffc107 !important;
	border-color: #fd7e14 !important;
	color: #343a40 !important !important;
	padding: 0px 21px !important;
	margin-top: 0.31rem;
}
</style>
<script>

	$('#grievance_sub_type').select2();
	$('#rulebox').hide();

	function addTask(num, yn)
	{
		console.log('-----new task-----');

		if(typeof yn==='undefined'){yn='';}
		var appendTo = '';
		if(typeof num==='undefined'){
		  num='';
		  appendTo = '#rulebox';
		}
		else{
		  appendTo = '#'+yn+num;
		}
		$(appendTo).show();
		appendTo = appendTo+'>tbody';
		numOrig=num;
		var i = j = parseInt($('#row_count'+yn+'_'+num).val())+1;

		console.log('#row_count'+yn+'_'+num);
		console.log('i: '+i);
		console.log('j: '+j);
		console.log(typeof num);
		console.log("num: "+num);
	  
		num=num.split('_');
		num.pop();
		num.push(i); 
		num=num.join('_');
		i='_'+num;
		k='_'+numOrig;
		
		console.log("i: "+i);
		console.log("j: "+j);
		console.log("k: "+k);
		console.log("appendTo: "+appendTo);
	   
		$(appendTo).append('<tr><td  width="15%"><select name="action'+yn+''+i+'" id="action'+yn+''+i+'" class="form-control select2"><option value="NULL">-Select Task-</option></select><br/><input type="hidden" name="active_act'+i+'" id="active_act'+i+'"><div id="para'+i+'"></div></td><td><select name="role'+yn+''+i+'" id="role'+yn+''+i+'" class="form-control select2" ><option value="NULL">-Select Role-</option></select></td><td>  <input type="textbox" class="form-control" id=task_tat'+yn+''+i+'" name="task_tat'+yn+''+i+'" placeholder="Task TAT"></td><td> <select name="task_process'+yn+''+i+'" id="task_process'+yn+''+i+'" class="form-control"><option value="NULL">-Select Process-</option></select></td><td class="text-center"><button type="button" class="btn btn-danger btn-sm" onClick="$(this).parents(\':eq(1)\').remove();calcTotal('+i+')"><i class="fas fa-times"></i></button></td></tr>');
		$('#action'+yn+''+i).html($('#action').html());
		$('#role'+yn+''+i).html($('#roledrp').html());
		$('#task_process'+yn+''+i).html($('#processdrp').html());
		$('#row_count'+yn+k).val(j);
	}
	
	function addCondition(num, yn)
	{
		console.log('-----new cond-----');

		if(typeof yn==='undefined'){yn='';}
		var appendTo = '';
		if(typeof num==='undefined'){
		  num='';
		  appendTo = '#rulebox';
		}
		else{
		  appendTo = '#'+yn+num;
		}
		$(appendTo).show();
		appendTo = appendTo+'>tbody';
		numOrig=num;
		var i = j = parseInt($('#row_count'+yn+'_'+num).val())+1;

		console.log('#row_count'+yn+'_'+num);
		console.log('i: '+i);
		console.log('j: '+j);
		console.log(typeof num);
		console.log("num: "+num);

		num=num.split('_');
		num.pop();
		num.push(i);
		num=num.join('_');
		i=yn+'_'+num;
		k='_'+numOrig;
		
		console.log("i: "+i);
		console.log("j: "+j);
		console.log("k: "+k);
		console.log("appendTo: "+appendTo);
	  
		$(appendTo).append('<tr><td  width="15%"><select name="condition'+i+'" id="condition'+i+'" class="form-control select2"  onchange="getParameter1('+i+');" ><option value="NULL" >-Select condition-</option></select><br/><input type="hidden" name="active_act'+i+'" id="active_act'+i+'"><div id="para'+i+'"></div></td><td><select name="condition_role'+i+'" id="condition_role'+i+'" class="form-control select2" ><option value="NULL">-Select Role-</option></select></td><td>  <input type="textbox" class="form-control" id=condition_tat'+i+'" name="condition_tat'+i+'" placeholder="add condition tat"></td><td> <select name="condition_process'+i+'" id="condition_process'+i+'" class="form-control"><option value="NULL">-Select Process-</option></select></td><td class="text-center"><button type="button" class="btn btn-danger btn-sm" onClick="$(this).parents(\':eq(1)\').remove();calcTotal('+i+')"><i class="fas fa-times"></i></button></td></tr><tr><td colspan="4"><b>Is True:</b><br/><button type="button" class="btn btn-info btn-sm yesaddtaskBtn" onclick="addTask(\''+num+'_1\',\'y\')">Add New Task</button>&nbsp;&nbsp;<button type="button" class="btn btn-info btn-sm yesaddactionBtn" onclick="addCondition(\''+num+'_1\',\'y\')">Add New Condition</button><input type="text" name="row_county_'+num+'_1" id="row_county_'+num+'_1" readonly value="0"><table class="table table-bordered" id="y'+num+'_1" style="display:none"><thead><tr><th style="padding-top: 0;text-transform: capitalize;padding-bottom: 0;">Method</th><th style="padding-top: 0;text-transform: capitalize;padding-bottom: 0;">User Role</th><th style="padding-top: 0;text-transform: capitalize;padding-bottom: 0;">TAT</th><th style="padding-top: 0;text-transform: capitalize;padding-bottom: 0;">Select Proces</th><th style="padding: 0px;"></th></tr></thead><tbody></tbody></table><td></tr><tr><td colspan="4"><b>Is False:</b><br/> <button type="button" class="btn btn-info btn-sm noaddtaskBtn" onclick="addTask(\''+num+'_1\',\'n\')">Add New Task</button>&nbsp;&nbsp;<button type="button" class="btn btn-info btn-sm noaddactionBtn" onclick="addCondition(\''+num+'_1\',\'n\')">Add New Condition</button><input type="text" name="row_countn_'+num+'_1" id="row_countn_'+num+'_1" readonly value="0"><table class="table table-bordered" id="n'+num+'_1" style="display:none"><thead><tr><th style="padding-top: 0;text-transform: capitalize;padding-bottom: 0;">Method</th><th style="padding-top: 0;text-transform: capitalize;padding-bottom: 0;">User Role</th><th style="padding-top: 0;text-transform: capitalize;padding-bottom: 0;">TAT</th><th style="padding-top: 0;text-transform: capitalize;padding-bottom: 0;">Select Proces</th><th style="padding: 0px;"></th></tr></thead><tbody></tbody></table></td></tr>');
		$('#condition'+i).html($('#action').html());
		$('#condition_role'+i).html($('#roledrp').html());
		$('#condition_process'+i).html($('#processdrp').html());
		$('#row_count'+yn+k).val(j);
	}


	function getParameter(num)
	{ 
	  var action_id = $('#action'+num).val();
	  var active_act = $('#active_act'+num).val();
	  active_act = active_act.split(',');

	  //console.log(typeof action_id);
	  //console.log(typeof active_act);
	  
	  var toAdd = action_id.filter(x => !active_act.includes(x));
	  var toDel = active_act.filter(x => !action_id.includes(x));

	 // console.log(toAdd);
	 // console.log(toDel);

	  if(toAdd.length > 0){
		$.ajax({
		  url: "<?php echo site_url('').'getParameter'?>",
		  type: 'post',
		  data: {action_id:toAdd,cnt:num},
		  success: function (data) 
		  {
			data=data.split('{#}');
			  //$('#active_act'+num).val(data[0]);
			  $('#active_act'+num).val(action_id);
			  $('#para'+num).append(data[1]);
			  calcExp(num);
		  }
		});
	  }

	  if(toDel.length > 0){
		for(x=0; x < toDel.length; x++){
		  $('#act'+toDel[x]).remove();
		}
		$('#active_act'+num).val(action_id);
		calcExp(num);
	  }
	}

	function calcExp(num){
	  var elems = $('#para'+num).find('input[type=text');
	  //console.log(elems);
	  var data=[], exp=[];
	  
	  var bm = 0;
	  elems.each(function(index){
		//console.log($(this).data('act'));
		//if(exp.indexOf($(this).data('act')) === -1){
		if(typeof exp[$(this).data('act')] == 'undefined'){
		  //exp.push($(this).data('act'));
		  exp[$(this).data('act')] = [];
		  bm = 0;
		  //console.log('new');
		}
		//console.log(bm);
		exp[$(this).data('act')][bm] = $(this).val();
		bm++;
		//data[index] = [$(this).data('act'), $(this).val()];
	  });
	  //console.log(exp);
	  //console.log(data);
  
	  var expr = '';

	  var x = 0;
	  for (const key in exp) {
	
		if(x > 0){// && x != (exp.length-1)){
		  expr += ' AND ';
		}

		expr += key + '('+exp[key].join()+')';

		x++;
	  }



	  $('#expression'+num).val(expr);
	}
</script>

<?php $this->endSection() ?>