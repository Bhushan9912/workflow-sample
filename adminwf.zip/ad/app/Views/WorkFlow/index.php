
<?php $this->extend('layouts/master')?>
<?php $this->section('content'); ?>
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
              
                <div class="col-10">
            
                </div>
                <div class="col-2 pull-right">
                <a href="<?php echo site_url('add_'.$url_slug)?>" class="btn  btn-sm btn-primary pull-right"><i class="fa fa-plus"></i> Add</a>
                </div>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                
                <table id="example1" class="table table-bordered table-striped">
                  <thead>
                  <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Action</th>
                  </tr>
                  </thead>
                  <tbody>
                  <?php foreach ($workflow as $key => $value): ?>    
                  <tr>
                    <td><?php echo $key+1 ;?></td>
                    <td><?php echo $value->work_flow_name?></td>
                    <td>
                      
                    
                        <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#modal-lg">
                      <i class="fas fa-eye" onclick="viewProduct(<?php echo $value->work_flow_id;?>)"></i>
                      </button>
                    
                       <button class="btn-sm btn-danger btn" onclick="delete_product(<?php echo $value->work_flow_id; ?>);"><i class="fas fa-trash-alt"></i></button></td>
                  </tr>
                  <?php endforeach; ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <div class="modal fade" id="modal-lg" style="display: none;" aria-hidden="true">
      <div class="modal-dialog modal-lg">
        <div class="modal-content" id="content">
          
        </div>
      </div>
    </div>  
    <div class="modal fade" id="modal-import" style="display: none;" aria-hidden="true">
      <div class="modal-dialog modal-sm">
        <div class="modal-content" id="content">
        <div class="card card-info">
              <div class="card-header">
                <h3 class="card-title">Upload Product data file </h3>
              </div>
              <form action="<?php echo site_url('import-csv');?>" method="post" class="form-horizontal" enctype="multipart/form-data">
              <?php csrf_field() ?>
                <div class="card-body">
                  <div class="form-group">
                    <label for="category_id">Upload Csv File</label>
                    <input type="file" class="form-control" id="file" name="file" >
                  </div>
                </div>
                <div class="card-footer">
                  <button type="submit" class="btn btn-info">Import File</button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>  
    <!-- DataTables  & Plugins -->
<script src="<?php echo site_url('public/assets/plugins/datatables/jquery.dataTables.min.js');?>"></script>
<script src="<?php echo site_url('public/assets/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js');?>"></script>
<script src="<?php echo site_url('public/assets/plugins/datatables-responsive/js/dataTables.responsive.min.js');?>"></script>
<script src="<?php echo site_url('public/assets/plugins/datatables-responsive/js/responsive.bootstrap4.min.js');?>"></script>

<script>
  $(function () {
    $("#example1").DataTable({
      "responsive": true, "lengthChange": false, "autoWidth": true,
    });
  });

  function viewProduct(pid)
  {
    var product_id = pid;
    $.ajax({
        url:"<?php echo site_url('').'workflow_details'?>",
        type:'post',
        data:{id:product_id},
        success:function(data)
        {
          $('#content').html(data);
        }
    });
  }


     function delete_product(p_id) 
    {  
      swal({
        title: "Workflow Delete",
        text: "Are You sure to delete workflow",
        icon: "error",
          buttons: [
            'Cancel',
            'Yes, change it!'
          ],
        }).then(function(isConfirm) {
            if (isConfirm) 
            { 
              $.ajax({
                    url: "<?php echo site_url('').'workflow_delete'?>",
                    type: 'post',
                    data: {pid:p_id},
                    success: function (data) 
                    {
                      swal("Success", "Workflow Deleted successfully.", "success");
                      location.reload();
                    }
                });
                  
            } 
          });
      
     }
</script>
<?php $this->endSection() ?>