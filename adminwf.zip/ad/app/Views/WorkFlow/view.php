<?php //echo $product[0]->product_name;exit;?>
<div class="modal-header">
    <h6 class="modal-title"><b>WorkFlow Name :<?php echo $workflow['work_flow_name'];?></b></h6>
    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">×</span>
    </button>
</div>
<div class="modal-body">
  <?php 
    echo "<pre>";
    //print_r($workflow);
    print_r(json_decode($workflow['workflow_json'],true));
  ?>
</div>
