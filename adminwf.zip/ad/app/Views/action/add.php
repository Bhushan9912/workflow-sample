
<?php $this->extend('layouts/master')?>
<?php $this->section('content'); ?>
<style>.table th, .table td{padding: .75rem;}</style>
    <section class="content">
    <div class="container-fluid">
        <div class="row">
          <div class="col-12">
          <div class="card card-info">
              <div class="card-header">
                <h3 class="card-title">Add Action</h3>
              </div>
              <form action="<?php echo site_url($url_slug.'_save');?>" method="post" class="form-horizontal" enctype="multipart/form-data">
              <?php csrf_field() ?>
                <div class="card-body">
                  <div class="row">
                    <div class="col-6">
                        <div class="form-group">
                            <label for="product_name">Action Name</label>
                            <input type="textbox" class="form-control" id="action_name" name="action_name" placeholder="Action Name">
                        </div> 
                    </div>
                    <div class="col-6">
                        <div class="form-group">
                            <label for="product_name">Expression <small><strong>(for ex. controller/method)</strong></small></label>
                            <input type="textbox" class="form-control" id="expression" name="expression" placeholder="Expression">
                        </div> 
                    </div>
                    </div>
                    <div class="col-5">
                 
                    <table class="table table-bordered" id="rulebox">
                      <thead>
                        <tr>
                          <th style="padding-top: 0;text-transform: capitalize;padding-bottom: 0;">Parameter Name</th>
                          <th style="padding: 0px;"></th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                            <td>
                                <input type="textbox" class="form-control" id=parameter_name1" name="parameter_name1" placeholder="Parameter Name">        
                            </td>
                            <td class="text-center">
                                <button type="button" class="btn btn-danger btn-sm" onClick="$(this).parents(':eq(1)').remove();calcTotal(1)"><i class="fas fa-times"></i></button>
                            </td>
                          </tr>
                      </tbody>
                      <tfoot>
                            <tr>
                                <th>
                                    <button type="button" class="btn btn-info btn-sm addBtn">Add New</button>
                                    <input type="hidden" name="row_cnt" id="row_cnt" value="1" readonly>
                               
                                </th>
                            </tr>
                        </tfoot>
                      
                    </table>

                    </div>
                  </div>
                </div>
                <div class="card-footer">
                  <button type="submit" class="btn btn-info float-right ml-2">Add Action</button>
                  <a href="<?php echo site_url('/manage_'.$url_slug)?>" class="btn btn-default float-right">Cancel</a>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- DataTables  & Plugins -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
    <script>
    $(document).on('click','.addBtn',function()
    {
        var i = parseInt($('#row_cnt').val())+1;
        $('#rulebox tbody').append('<tr><td><input type="textbox" class="form-control" id=parameter_name'+i+'" name="parameter_name'+i+'" placeholder="Parameter Name"></td><td class="text-center"><button type="button" class="btn btn-danger btn-sm" onClick="$(this).parents(\':eq(1)\').remove();calcTotal('+i+')"><i class="fas fa-times"></i></button></td></tr>');
        $('#row_cnt').val(i);
    });
</script>
<?php $this->endSection() ?>