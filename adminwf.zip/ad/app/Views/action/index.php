
<?php $this->extend('layouts/master')?>
<?php $this->section('content'); ?>
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
              
                <div class="col-10">
            
                </div>
                <div class="col-2 pull-right">
                <a href="<?php echo site_url('add_'.$url_slug)?>" class="btn  btn-sm btn-primary pull-right"><i class="fa fa-plus"></i> Add</a>
                </div>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                
                <table id="example1" class="table table-bordered table-striped">
                  <thead>
                  <tr>
                    <th>#</th>
                    <th>Name</th>
                 </tr>
                  </thead>
                  <tbody>
                  <?php foreach ($action as $key => $value): ?>    
                  <tr>
                    <td><?php echo $key+1 ;?></td>
                    <td><?php echo $value->action_name?></td>
                    <td>
                       <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#modal-lg">
                       <i class="fas fa-eye" onclick="viewProduct(<?php echo $value->action_id;?>)"></i>
                      </button>
                       <button class="btn-sm btn-danger btn" onclick="delete_product(<?php echo $value->action_id; ?>);"><i class="fas fa-trash-alt"></i></button></td>
                  </tr>
                  <?php endforeach; ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <div class="modal fade" id="modal-lg" style="display: none;" aria-hidden="true">
      <div class="modal-dialog modal-lg">
        <div class="modal-content" id="content">
          
        </div>
      </div>
    </div>  
     
    <!-- DataTables  & Plugins -->
<script src="<?php echo site_url('public/assets/plugins/datatables/jquery.dataTables.min.js');?>"></script>
<script src="<?php echo site_url('public/assets/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js');?>"></script>
<script src="<?php echo site_url('public/assets/plugins/datatables-responsive/js/dataTables.responsive.min.js');?>"></script>
<script src="<?php echo site_url('public/assets/plugins/datatables-responsive/js/responsive.bootstrap4.min.js');?>"></script>

<script>
  $(function () {
    $("#example1").DataTable({
      "responsive": true, "lengthChange": false, "autoWidth": true,
    });
  });

  function viewProduct(pid)
  {
    var product_id = pid;
    $.ajax({
        url:"<?php echo site_url('').'action_details'?>",
        type:'post',
        data:{id:product_id},
        success:function(data)
        {
          $('#content').html(data);
        }
    });
  }


     function delete_product(p_id) 
    {  
      swal({
        title: "Action Delete",
        text: "Are You sure to delete action",
        icon: "error",
          buttons: [
            'Cancel',
            'Yes, change it!'
          ],
        }).then(function(isConfirm) {
            if (isConfirm) 
            { 
              $.ajax({
                    url: "<?php echo site_url('').'action_delete'?>",
                    type: 'post',
                    data: {pid:p_id},
                    success: function (data) 
                    {
                      swal("Success", "Action Deleted successfully.", "success");
                      location.reload();
                    }
                });
                  
            } 
          });
      
     }
</script>
<?php $this->endSection() ?>