<?php //echo $product[0]->product_name;exit;?>
<div class="modal-header">
    <h6 class="modal-title"><b>Action Name :<?php echo $action['action_name'];?></b></h6>
    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">×</span>
    </button>
</div>
<div class="modal-body">
   <table class="table table-bordered ">
     <tr>
       <th>Syntax:</th>
       <td>
         <b><?php echo $action['expression'];?>(</b>
          <?php 
          $comma = "";
          $i=1;
          foreach($action_list as $value){
               
            if($i>1)
            {
              $comma = ",";
            }
            else{
              $comma = '';
            }
            echo $comma."".$value->parameter_name ;
            $i++;
          }
        ?><b>)</b>
       </td>
     </tr>
     

   </table>
   
</div>
