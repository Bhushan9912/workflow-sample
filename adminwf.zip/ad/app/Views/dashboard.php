<?php $this->extend('layouts/master')?>
<?php $this->section('content');  ?>
<p>TEST</p>
<?php $this->endSection() ?>