<?php   $session = session(); ?>
<?=$this->include('layouts/header') ?>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">
  <!-- Preloader -->
  <div class="preloader flex-column justify-content-center align-items-center">
    <img class="animation__shake" src="<?php echo site_url('public/assets/dist/img/AdminLTELogo.png');?>" alt="AdminLTELogo" height="60" width="60">
  </div>
  
  <!--Sidebar Add-->
  <?=$this->include('layouts/sidebar')?>

  <!--Main Containt-->
  <div class="content-wrapper">
    <?php if(!empty($title)){?>
  <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1><?php echo $title;?></h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active"><?php echo $title;?></li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
</section>
<?php }?>
<?=$this->include('layouts/alert')?>
  <?= $this->renderSection('content') ?>
  </div>
  
  <!--Footer section-->
  <?=$this->include('layouts/footer')?>

  <aside class="control-sidebar control-sidebar-dark">

  </aside>

</div>


<script>
  $.widget.bridge('uibutton', $.ui.button)
</script>
<script src="<?php echo site_url('public/assets/plugins/bootstrap/js/bootstrap.bundle.min.js');?>"></script>
<script src="<?php echo site_url('public/assets/plugins/chart.js/Chart.min.js');?>"></script>
<script src="<?php echo site_url('public/assets/plugins/sparklines/sparkline.js');?>"></script>
<script src="<?php echo site_url('public/assets/plugins/jqvmap/jquery.vmap.min.js');?>"></script>
<script src="<?php echo site_url('public/assets/plugins/jqvmap/maps/jquery.vmap.usa.js');?>"></script>
<script src="<?php echo site_url('public/assets/plugins/jquery-knob/jquery.knob.min.js');?>"></script>
<script src="<?php echo site_url('public/assets/plugins/moment/moment.min.js');?>"></script>
<script src="<?php echo site_url('public/assets/plugins/daterangepicker/daterangepicker.js');?>"></script>
<script src="<?php echo site_url('public/assets/plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js');?>"></script>
<script src="<?php echo site_url('public/assets/plugins/summernote/summernote-bs4.min.js');?>"></script>
<script src="<?php echo site_url('public/assets/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js');?>"></script>
<script src="<?php echo site_url('public/assets/dist/js/adminlte.js');?>"></script>
<script src="<?php echo site_url('public/assets/dist/js/demo.js');?>"></script>
<script src="<?php echo site_url('public/assets/dist/js/pages/dashboard.js');?>"></script>
<script src="<?php echo site_url('public/assets/plugins/bootstrap/js/bootstrap.bundle.min.js');?>"></script>

</body>
</html>
