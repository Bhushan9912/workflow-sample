<?php
namespace App\Controllers;
use CodeIgniter\Controller;
use App\Models\CategoryModel;
use App\Models\ApiModel;
class Category extends BaseController
{
    Public function __construct()
    {  
        $this->session = session();
        $this->title = 'Main Category'; 
        $this->url_slug = 'main_category'; 
        $this->folder_path = 'maincategory/'; 
    }

    public function index()
    {  
       $data=[]; 
       $model = new  CategoryModel();
       $cat_list = $model->findAll();
       $data['category'] = $cat_list;
       $data['title']    = $this->title;

       return view($this->folder_path.'index',$data);
    }

    public function add()
    {  
       $data=[]; 
       $data['title']     = $this->title." Add";
       return view($this->folder_path.'add',$data);
    }

    public function store()
    {
        helper(['form','url']);
        $validation =   \Config\Services::validation();
        $check      =   $this->validate([
                'mcategory_name'     =>'required',
        ]);

        if(!$check)
        {
             $msg = $this->validator->listErrors();
             $this->session->setFlashdata('error','Enter category name');
             return redirect()->to('add_'.$this->url_slug); 
        }
        else
        { 
            
            $model = new CategoryModel();
            $data  = [
                       'mcategory_name'     => $this->request->getvar('mcategory_name'),
                     ];
            $save  = $model->insert($data);        
            if($save)
            {      
                $this->session->setFlashdata('success', 'Main Category added successfully');
                return redirect()->to('manage_'.$this->url_slug); 
            }
            else
            {
                $this->session->setFlashdata('error', 'Something is wrong.');
                return redirect()->to('manage_'.$this->url_slug); 
            }
        }  
    }

    public function edit($id=NULL)
    {          
       
       $model = new CategoryModel();
       $result = $model->where('mcategory_id',$id)->first();
       $data=[]; 
       $data['title']  = $this->title." Edit";
       $data['row']    = $result;
       return view($this->folder_path.'edit',$data);
    }

    public function update()
    {
        $id = $this->request->getvar('mcategory_id');
        helper(['form','url']);
        $validation =   \Config\Services::validation();
        $check      =   $this->validate([
                'mcategory_name'     =>'required',
        ]);

        if(!$check)
        {
             $msg = $this->validator->listErrors();
             $this->session->setFlashdata('error','Enter category name');
             return redirect()->to('edit_'.$this->url_slug.'/'.$this->request->getvar('mcategory_id')); 
        }
        else
        { 
            
            $model = new CategoryModel();
            $data  = [
                       'mcategory_name'     => $this->request->getvar('mcategory_name'),
                       'updated_at'        => date('Y-m-d H:i:s'),
                     ];
            $update  = $model->update($id,$data);  
            if($update)
            {      
                $this->session->setFlashdata('success', 'Main Category updated successfully');
                return redirect()->to('manage_'.$this->url_slug); 
            }
            else
            {
                $this->session->setFlashdata('error', 'Something is wrong.');
                return redirect()->to('manage_'.$this->url_slug); 
            }
        }  
    }

    public function delete($id=Null){

        $model = new CategoryModel();
  
        if($model->find($id)){
           $model->delete($id);
            $this->session->setFlashdata('success', 'Main Category Deleted successfully');
            return redirect()->to('manage_'.$this->url_slug); 
        }else{
            $this->session->setFlashdata('error', 'Something is wrong.');
            return redirect()->to('manage_'.$this->url_slug); 
        }
  
        return redirect()->route('/');
  
     }

     public function status()
     {
         
         $model   = new CategoryModel();
         $status  = $this->request->getvar('status');
         $id      = $this->request->getvar('pid');
         $data               = [];
         if($status=="true")
         {
           $data = ['active' => 'y','updated_at'=> date('Y-m-d H:i:s')];
         }
         if($status=="false")
         {
           $data= ['active' => 'n','updated_at' => date('Y-m-d H:i:s')];
         } 
 
         $update  = $model->update($id,$data);  
     
     }
     
     public  function from_control_add(){
       $data=[]; 
       $data['title']     = $this->title." Add";
       return view('api/add',$data);
     }

     public  function from_control_save()
     {
        $model = new ApiModel();
        $file  = $this->request->getFile('image');
        $image_name = rand().$file->getName();
        $data  = [
                   'name'           => $this->request->getvar('name'),
                   'city'           => $this->request->getvar('city'),
                   'gender'         => $this->request->getvar('gender'),
                   'education'      => implode(",",$this->request->getvar('education')),
                   'image'          => $image_name,
                   'descr'          => $this->request->getvar('descr'),
                 ];

        $save  = $model->insert($data);     

        if($save)
        {      
            $file->move(ROOTPATH . 'public/assets/img/product',$image_name);
            $this->session->setFlashdata('success', 'Added successfully.');
            return redirect()->to('manage_'.$this->url_slug); 
        }
        else
        {
            $this->session->setFlashdata('error', 'Something is wrong.');
            return redirect()->to('manage_'.$this->url_slug); 
        }

            
     } 
 

}
