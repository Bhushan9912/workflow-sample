<?php
namespace App\Controllers;
use CodeIgniter\Controller;
use App\Models\RegisterModel;
class Home extends BaseController
{
    public function index()
    {
       return view('login');
    }
    
    public function login_action()
    {
        //check value database or not
        $model  = new RegisterModel();
        $result = $model->where('email',$this->request->getvar('email'))->where('password',md5($this->request->getvar('password')))->first();
      
        $session = session();
        if(!empty($result))
        {
        
            $session->set('user_name',$result['name']);
            $session->set('user_id',$result['id']);
            return redirect()->to('dashboard'); 
        }
        else
        {   
            $session->setFlashdata("message", "Invalid Login details");
            return view('login');
        } 
       
    }

    public function dashboard()
    {
        $data=[];
        $data['title']="Dashboard";
        return view('dashboard',$data);
    }

    public function logout()
    {
        $session = session();
        $session->destroy();
        return view('login');
    }
}
