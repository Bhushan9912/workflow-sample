<?php
namespace App\Controllers;
use CodeIgniter\Controller;
use App\Models\OperatorModel;
use App\Models\ApiModel;
class Operator extends BaseController
{
    Public function __construct()
    {  
        $this->session = session();
        $this->title = 'Operator'; 
        $this->url_slug = 'operator'; 
        $this->folder_path = 'operator/'; 
    }

    public function index()
    {  
       $data=[]; 
       $model = new  OperatorModel();
       $operator_list = $model->findAll();
       $data['operator'] = $operator_list;
       $data['title']    = $this->title;

       return view($this->folder_path.'index',$data);
    }

    public function add()
    {  
       $data=[]; 
       $data['title']     = $this->title." Add";
       return view($this->folder_path.'add',$data);
    }

    public function store()
    {
        helper(['form','url']);
        $validation =   \Config\Services::validation();
        $check      =   $this->validate([
                'operator_name'     =>'required',
        ]);

        if(!$check)
        {
             $msg = $this->validator->listErrors();
             $this->session->setFlashdata('error','Enter operator name');
             return redirect()->to('add_'.$this->url_slug); 
        }
        else
        { 
            
            $model = new OperatorModel();
            $data  = [
                       'operator_name'     => $this->request->getvar('operator_name'),
                     ];
            $save  = $model->insert($data);        
            if($save)
            {      
                $this->session->setFlashdata('success', 'Operator added successfully');
                return redirect()->to('manage_'.$this->url_slug); 
            }
            else
            {
                $this->session->setFlashdata('error', 'Something is wrong.');
                return redirect()->to('manage_'.$this->url_slug); 
            }
        }  
    }


    public function delete($id=Null){

        $model = new OperatorModel();
  
        if($model->find($id)){
           $model->delete($id);
            $this->session->setFlashdata('success', 'Operator Deleted successfully');
            return redirect()->to('manage_'.$this->url_slug); 
        }else{
            $this->session->setFlashdata('error', 'Something is wrong.');
            return redirect()->to('manage_'.$this->url_slug); 
        }
  
        return redirect()->route('/');
  
     }
 

}
