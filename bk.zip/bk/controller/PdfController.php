<?php 
namespace App\Controllers;
use CodeIgniter\Controller;
use App\Models\ProductModel;
use App\Models\ProductCategoryModel;
use App\Models\CategoryModel;
class PdfController extends Controller
{
    private $db;
    Public function __construct()
    {  
        $this->db = db_connect();
        $this->session = session();
    }
    public function index($id) 
	{
       $data=[]; 
       $product = $this->db->table("product as p");
       $product->select('p.*, c.category_name');
       $product->join('category as c', 'p.category_id = c.category_id');
       $product->where('product_id',$id);
       $result = $product->get()->getResult();
      /*  print_R($result);
       exit; */
       $data['product'] = $result;
       return view('product/pdf_view',$data);
    }

    public function htmlToPDF(){
        $dompdf = new \Dompdf\Dompdf(); 
        $dompdf->loadHtml(view('product/pdf_view'));
        $dompdf->setPaper('A4', 'landscape');
        $dompdf->render();
        $dompdf->stream();
    }

}