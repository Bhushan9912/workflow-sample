<?php
namespace App\Controllers;
use CodeIgniter\Controller;
use App\Models\ProductModel;
use App\Models\ProductCategoryModel;
use App\Models\CategoryModel;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
/**
 * Class Product
 *
 * Product controller provides a product crud operation s
 * and performing functions that are needed by all your controllers.
 * Extend this class in any new controllers:
 *    
 *
 * For security be sure to declare any new methods as protected or private.
 */
class Product extends BaseController
{
    private $db;
    Public function __construct()
    {  
        $this->db = db_connect();
        $this->session = session();
        $this->title = 'Product'; 
        $this->url_slug = 'product'; 
        $this->folder_path = 'product/'; 
    }
    /**
     * Index Method
     *
     * It inculde product listing functionality
     *    
     *
     * 
     */
    public function index()
    {  
       $data=[]; 
       //$model = new  ProductModel();
       //$product_list = $model->findAll();
       $product = $this->db->table("product as p");
       $product->select('p.*, c.category_name,m.mcategory_name');
       $product->join('category as c', 'p.category_id = c.category_id');
       $product->join('maincategory as m', 'p.mcategory_id = m.mcategory_id');
       $product_list = $product->get()->getResult();
       $data['product'] = $product_list;
       $data['title']    = $this->title;
       $data['url_slug']    = $this->url_slug;

       return view($this->folder_path.'index',$data);
    }

    public function add()
    {  
      
       $data=[]; 
       $model = new  ProductCategoryModel();
       $catmodel = new  CategoryModel();
       $cat_list = $model->where('active','y')->findAll();
       $m_cat_list = $catmodel->where('active','y')->findAll();

       $data['category'] = $cat_list;
       $data['maincategory'] = $m_cat_list;
       $data['title']    = $this->title." Add";
       $data['url_slug']    = $this->url_slug;
       return view($this->folder_path.'add',$data);
    }

    public function store()
    {
        helper(['form','url']);
        $validation =   \Config\Services::validation();
        $check      =   $this->validate([
                'product_name'     =>'required',
        ]);

        if(!$check)
        {
             $msg = $this->validator->listErrors();
             $this->session->setFlashdata('error','Please enter all fields.');
             return redirect()->to('add_'.$this->url_slug); 
        }
        else
        { 
            
            $model = new ProductModel();
            $file = $this->request->getFile('image');
            $image_name = rand().$file->getName();
            $data  = [
                       'product_name'     => $this->request->getvar('product_name'),
                       'category_id'      => $this->request->getvar('category_id'),
                       'mcategory_id'      => $this->request->getvar('mcategory_id'),
                       'image'            => $image_name,
                       'descr'            => $this->request->getvar('descr'),
                       'product_price'    => $this->request->getvar('product_price'),
                     ];
            $save  = $model->insert($data);        
            if($save)
            {      
                $file->move(ROOTPATH . 'public/assets/img/product',$image_name);
                $this->session->setFlashdata('success', 'Product added successfully');
                return redirect()->to('manage_'.$this->url_slug); 
            }
            else
            {
                $this->session->setFlashdata('error', 'Something is wrong.');
                return redirect()->to('manage_'.$this->url_slug); 
            }
        }  
    }

    public function edit($id=NULL)
    {          
       $data=[]; 
       $category_model = new  ProductCategoryModel();
       $main_category_model = new  CategoryModel();
       $product_model = new ProductModel();
       $result = $product_model->where('product_id',$id)->first();
       $cat_list = $category_model->findAll();
       $main_cat_list = $main_category_model->findAll();
       $data['category'] = $cat_list;
       $data['maincategory'] = $main_cat_list;
       $data['title']  = $this->title." Edit";
       $data['row']    = $result;
       return view($this->folder_path.'edit',$data);
    }

    public function update()
    {
        $id = $this->request->getvar('product_id');
        helper(['form','url']);
        $validation =   \Config\Services::validation();
        $check      =   $this->validate([
                'product_name'     =>'required',
        ]);

        if(!$check)
        {
             $msg = $this->validator->listErrors();
             $this->session->setFlashdata('error','Please Enter all fields.');
             return redirect()->to('edit_'.$this->url_slug.'/'.$this->request->getvar('product_id')); 
        }
        else
        { 
            $file = $this->request->getFile('image');
         
            if($file->isValid())
            {
                $image_name = rand().$file->getName();
                $file->move(ROOTPATH . 'public/assets/img/product',$image_name);
                unlink(ROOTPATH . 'public/assets/img/product/'.$this->request->getvar('old_image'));
            }
            else
            {
                $image_name =  $this->request->getvar('old_image');
            }
            $model = new ProductModel();
            $data  = [
                        'product_name'     => $this->request->getvar('product_name'),
                        'category_id'      => $this->request->getvar('category_id'),
                        'mcategory_id'     => $this->request->getvar('mcategory_id'),
                        'image'            => $image_name,
                        'descr'            => $this->request->getvar('descr'),
                        'product_price'    => $this->request->getvar('product_price'),
                        'updated_at'       => date('Y-m-d H:i:s')
                     ];
            $update  = $model->update($id,$data);  
            if($update)
            {      
                
                $this->session->setFlashdata('success', 'Product updated successfully');
                return redirect()->to('manage_'.$this->url_slug); 
            }
            else
            {
                $this->session->setFlashdata('error', 'Something is wrong.');
                return redirect()->to('manage_'.$this->url_slug); 
            }
        }  
    }

    public function delete()
    {
        $id= $this->request->getvar('pid');
        $model = new ProductModel();
  
        if($model->find($id)){
           $model->delete($id);
            $this->session->setFlashdata('success', 'Product Deleted successfully');
            return redirect()->to('manage_'.$this->url_slug); 
        }else{
            $this->session->setFlashdata('error', 'Something is wrong.');
            return redirect()->to('manage_'.$this->url_slug); 
        }
  
        return redirect()->route('/');
  
     }

    public function detail()
    {
        
       $id= $this->request->getvar('id');

       $data=[]; 
       $product = $this->db->table("product as p");
       $product->select('p.*, c.category_name');
       $product->join('category as c', 'p.category_id = c.category_id');
       $product->where('product_id',$id);
       $result = $product->get()->getResult();
       
       $data['product'] = $result;
       $data['title']  = $this->title." Edit";
       return view($this->folder_path.'view',$data);
    } 

    public function status()
    {
        
        $model   = new ProductModel();
        $status  = $this->request->getvar('status');
        $id      = $this->request->getvar('pid');
        $data               = [];
        if($status=="true")
        {
          $data = ['active' => 'y','updated_at'=> date('Y-m-d H:i:s')];
        }
        if($status=="false")
        {
          $data= ['active' => 'n','updated_at' => date('Y-m-d H:i:s')];
        } 

        $update  = $model->update($id,$data);  
    
    }
     
    function export()
	{
        $product = $this->db->table("product as p");
        $product->select('p.*, c.category_name');
        $product->join('category as c', 'p.category_id = c.category_id');
        $result = $product->get()->getResult();
		//$data = $result->get()->getResult();
        /* echo"<pre>";
        print_r($result);
        exit; */
		$file_name = 'product.xlsx';

		$spreadsheet = new Spreadsheet();

		$sheet = $spreadsheet->getActiveSheet();

		$sheet->setCellValue('A1', 'Product Name');

		$sheet->setCellValue('B1', 'Product category');

		$sheet->setCellValue('C1', 'Description');

		
		$count = 2;

		foreach($result as $row)
		{
			$sheet->setCellValue('A' . $count, $row->product_name);

			$sheet->setCellValue('B' . $count, $row->category_name);

			$sheet->setCellValue('C' . $count, $row->descr);

			$count++;
		}

		$writer = new Xlsx($spreadsheet);

		$writer->save($file_name);

		header("Content-Type: application/vnd.ms-excel");

		header('Content-Disposition: attachment; filename="' . basename($file_name) . '"');

		header('Expires: 0');

		header('Cache-Control: must-revalidate');

		header('Pragma: public');

		header('Content-Length:' . filesize($file_name));

		flush();

		readfile($file_name);

		exit;
	}


    public function importCsvToDb()
    {
        $input = $this->validate([
            'file' => 'uploaded[file]|max_size[file,2048]|ext_in[file,csv],'
        ]);

        if (!$input) {
            $data['validation'] = $this->validator;
            return view('index', $data); 
        }else{

            if($file = $this->request->getFile('file')) {
            if ($file->isValid() && ! $file->hasMoved()) {
                $newName = $file->getRandomName();
                $file->move('../../public/csvfile', $newName);
                $file = fopen("../../public/csvfile/".$newName,"r");
                $i = 0;
                $numberOfFields = 6;

                $csvArr = array();
                
                while (($filedata = fgetcsv($file, 1000, ",")) !== FALSE) {
                    $num = count($filedata);
                
                    if($i > 0 && $num == $numberOfFields){ 
                        $csvArr[$i]['category_id'] = $filedata[0];
                        $csvArr[$i]['mcategory_id'] = $filedata[1];
                        $csvArr[$i]['product_name'] = $filedata[2];
                        $csvArr[$i]['image'] = $filedata[3];
                        $csvArr[$i]['descr'] = $filedata[4];
                        $csvArr[$i]['created_at'] = $filedata[5];

                    }
                    $i++;
                }
                //print_r($csvArr);exit;
                fclose($file);

                $count = 0;
                foreach($csvArr as $value_data){
                    $model   = new ProductModel();

                    $findRecord = $model->where('product_name', $value_data['product_name'])->countAllResults();
                    //print_r($findRecord);exit;
                    if($findRecord == 0){
                        if($model->insert($value_data)){
                            $count++;
                        }
                    }
                }
                $this->session->setFlashdata('success', $count.' rows successfully added.');
                return redirect()->to('manage_'.$this->url_slug);
            }
            else{
                $this->session->setFlashdata('error', 'CSV file coud not be imported.');
                return redirect()->to('manage_'.$this->url_slug);
            }
            }else{
            $this->session->setFlashdata('error', 'CSV file coud not be imported.');
            return redirect()->to('manage_'.$this->url_slug);
            }

        }

       //return $this->session->setFlashdata('success', 'Product upload successfully');
        //return redirect()->to('manage_'.$this->url_slug);          
    }
    

    public function product_list()
    {  
       $data=[]; 
       $product = $this->db->table("product as p");
       $product->select('p.*, c.category_name,m.mcategory_name');
       $product->join('category as c', 'p.category_id = c.category_id');
       $product->join('maincategory as m', 'p.mcategory_id = m.mcategory_id');
       $product_list = $product->get()->getResult();
       $data['product'] = $product_list;
       $data['title']    = $this->title;
       $data['url_slug']    = $this->url_slug;

       return view($this->folder_path.'product_list',$data);
    } 

}
