<?php
namespace App\Controllers;
use CodeIgniter\RESTful\ResourceController;
use App\Models\CategoryModel;
use App\Models\ProductCategoryModel;
use App\Models\ProductModel;

/**
 * Class Product
 *
 * Product controller provides a product crud operation s
 * and performing functions that are needed by all your controllers.
 * Extend this class in any new controllers:
 *    
 *
 * For security be sure to declare any new methods as protected or private.
 */
class ProductApi extends ResourceController
{
    private $db;
    Public function __construct()
    {  
        $this->db = db_connect();
        $this->session = session();
        $this->title = 'Product'; 
        $this->url_slug = 'product'; 
        $this->folder_path = 'product/'; 
    }
    
    
    public function product_store()
    {

        $model = new ProductModel();
        $file = $this->request->getFile('image');
        $image_name = rand().$file->getName();
        $data  = [
                    'product_name'     => $this->request->getvar('product_name'),
                    'category_id'      => $this->request->getvar('category_id'),
                    'mcategory_id'     => $this->request->getvar('mcategory_id'),
                    'image'            => $image_name,
                    'descr'            => $this->request->getvar('descr'),
                    'product_price'            => $this->request->getvar('product_price'),
                    ];
        $save  = $model->insert($data);        
        if($save)
        {      
            $file->move(ROOTPATH . 'public/assets/img/product',$image_name);
            $response = [
                'status'   => 200,
                'error'    => null,
                'messages' => [
                    'success' => 'Product added successfully.'
                ]
            ];
        }
        else
        {
            $response = [
                'status'   => 500,
                'error'    => null,
                'messages' => [
                    'success' => 'Something is wrong.'
                ]
            ];
            
        }
        return $this->respondCreated($response);
       
    }


    public function product_update()
    {
        $id = $this->request->getvar('product_id');
        helper(['form','url']);
     
       
            $file = $this->request->getFile('image');
         
            if($file->isValid())
            {
                $image_name = rand().$file->getName();
                $file->move(ROOTPATH . 'public/assets/img/product',$image_name);
                unlink(ROOTPATH . 'public/assets/img/product/'.$this->request->getvar('old_image'));
            }
            else
            {
                $image_name =  $this->request->getvar('old_image');
            }
            $model = new ProductModel();
            $data  = [
                        'product_name'     => $this->request->getvar('product_name'),
                        'category_id'      => $this->request->getvar('category_id'),
                        'mcategory_id'     => $this->request->getvar('mcategory_id'),
                        'image'            => $image_name,
                        'descr'            => $this->request->getvar('descr'),
                        'product_price'    => $this->request->getvar('product_price'),
                        'updated_at'       => date('Y-m-d H:i:s')
                     ];
            $update  = $model->update($id,$data);  
           /*  if($update)
            {      
                $response = [
                    'status'   => 200,
                    'error'    => null,
                    'messages' => [
                        'success' => 'Product update successfully.'
                    ]
                ];
            }
            else
            {
                $response = [
                    'status'   => 500,
                    'error'    => null,
                    'messages' => [
                        'success' => 'Something is wrong.'
                    ]
                ];
            } */

            $response = [
                'status'   => 200,
                'error'    => null,
                'messages' => [
                    'success' => 'Product update successfully.'
                ]
            ];
            return $this->respondCreated($response);
    }

   

 

    
     

}
