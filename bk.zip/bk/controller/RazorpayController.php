<?php
namespace App\Controllers;
use App\Controllers\BaseController;
use App\Models\TransactionModel;
use Razorpay\Api\Api;

class RazorpayController extends BaseController
{
    private $db;
    Public function __construct()
    {  
        $this->db = db_connect();
        $this->session = session();
        $this->title = 'Product'; 
        $this->url_slug = 'product'; 
        $this->folder_path = 'product/'; 
    }
    public function payWithRazorpay()
    {
       $data=[]; 
       $product = $this->db->table("product as p");
       $product->select('p.*, c.category_name,m.mcategory_name');
       $product->join('category as c', 'p.category_id = c.category_id');
       $product->join('maincategory as m', 'p.mcategory_id = m.mcategory_id');
       $product_list = $product->get()->getResult();
       $data['product'] = $product_list;
       $data['title']    = "Product List";
       return view($this->folder_path.'product_list',$data);
    }
    public function transaction()
    {
       $data=[]; 
       $transaction = $this->db->table("product as p");
       $transaction->select('p.product_name, c.*');
       $transaction->join('transactions as c', 'p.product_id = c.product_id');
       $transaction_list = $transaction->get()->getResult();
       $data['transaction'] = $transaction_list;
       $data['title']    = "Transaction List";
       return view($this->folder_path.'transaction',$data);
    }
   
    public function processPayment()
    {

        $input = $this->request->getVar();
        $api = new Api(env('razorKey'), env('razorSecret'));
        $payment = $api->payment->fetch($input['razorpay_payment_id']);
        if (count($input) && !empty($input['razorpay_payment_id'])) {
            try {

                $response = $api->payment->fetch($input['razorpay_payment_id'])->capture(array('amount' => $payment['amount']));
            /*     echo"<pre>";
                print_r($response);
                exit; */
                if($response){




                    $save_history = new TransactionModel();
                    $save_history->insert([
                        "product_id" => $this->request->getVar('product_id'),
                        "email" => $response->email,
                        "contact" => $response->contact,
                        "amount" => $response->amount,
                        "currency" => $response->currency,
                        "trnx_id" => $response->id,
                        "card_id" => $response->card_id,
                        "status" => $response->status,
                        "transaction_date" => date('Y-m-d')
                    ]);
                        
                        /*  
                           $email = \Config\Services::email();
                            $email->setTo($to);
                            $email->setFrom('bhushgit@gmail.com', 'Sample Mail');
                            $email->setSubject($subject);
                            $email->setMessage($message);
                            $email->send()
                        */
                    session()->setFlashdata('success', 'Payment successfully done');
                    return redirect()->back();
                
                }

            } catch (\Exception $e) {
                //return $e->getMessage();
                session()->setFlashdata("error", $e->getMessage());
                return redirect()->back();
            }

            
        }

        
    }
}