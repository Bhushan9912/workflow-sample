<?php
namespace App\Controllers;
use CodeIgniter\Controller;
use App\Models\RegisterModel;
class Register extends BaseController
{
    Public function __construct()
    {  
        $this->session = session(); 
    }
    public function index()
    {
       return view('reg');
    }

    public  function register()
    {
        helper(['form','url']);
        $validation =   \Config\Services::validation();
        $check      =   $this->validate([
                'name'     =>'required',
                'email'    =>'required',
                'password' =>'required',
                'cpassword'=>'required|matches[password]',
        ]);

        if(!$check)
        {
            return view('reg',['validation'=>$this->validator]);
        }else
        { 
            
        
            $model = new RegisterModel();
           

            $data  = [
                       'name'     => $this->request->getvar('name'),
                       'email'    => $this->request->getvar('email'),
                       'password' => md5($this->request->getvar('password')),
                    ];
            $save= $model->insert($data);        
            if($save)
            {      
                
                $this->session->setFlashdata('success', 'User Registration successfully');
                return redirect()->to('reg'); 
            }
            else
            {
                $this->session->setFlashdata('error', 'Something is wrong.');
                return redirect()->to('reg'); 
            }
        }    
    }


}
