<?php
namespace App\Controllers;
use CodeIgniter\Controller;
use App\Models\WorkflowModel;
class RuleController extends BaseController
{
    private $childActionMethod;


    Public function __construct()
    {  
        $this->session = session();
    }
    
  
    public function on_save_changes(){
        if(method_exists($this, $this->childActionMethod)) {
            call_user_func_array(array($this, $this->childActionMethod), func_get_args());
        }
        else {
            throw new Exception('Child Method has not been set');
        }
    }

    protected function setChildActionMethod($methodName) {
        $this->childActionMethod = $methodName;
    }
    
 

}
