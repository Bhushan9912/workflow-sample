<?php 
namespace App\Controllers;
use CodeIgniter\Controller;
use App\Models\ProductModel;
use App\Models\ProductCategoryModel;
use App\Models\CategoryModel;
/**
 * Class Send Mail 
 * SendMail provides a sending mail functionality. 
 * This class define multiple method regarding sending mail functionality .
 */
/**
 * @author Bhushan 
 * @author Bhushan  <my.name@example.com>
 */
class SendMail extends Controller
{
    private $db;

    Public function __construct()
    {  
        $this->db = db_connect();
        $this->session = session();
        $this->title = 'Mail'; 
        $this->url_slug = 'mail'; 
        $this->folder_path = 'mail/'; 
    }

    public function index()
    {  
       return view($this->folder_path.'index');
    }

    public function send_mail()
    {  
        $to = $this->request->getVar('email');
        $subject = $this->request->getVar('subject');
        $message = $this->request->getVar('message');
        
        $email = \Config\Services::email();

        $email->setTo($to);
        $email->setFrom('bhushgit@gmail.com', 'Sample Mail');
        
        $email->setSubject($subject);
        $email->setMessage($message);

        if ($email->send()) 
		{
            $this->session->setFlashdata('success', 'Email successfully sent');
            return redirect()->to('send_mail'); 
        } 
		else 
		{
            $data = $email->printDebugger(['headers']);
            print_r($data);
        }

    }

}