<?php 
namespace App\Models;

use CodeIgniter\Model;

class ApiModel extends Model
{
    protected $table = 'api';
    protected $primaryKey = 'id'; 
    protected $allowedFields = ['name','gender','city','education','image','descr','created_at','updated_at'];
}


?>