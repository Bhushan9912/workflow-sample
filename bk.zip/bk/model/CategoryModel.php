<?php 
namespace App\Models;

use CodeIgniter\Model;

class CategoryModel extends Model
{
    protected $table = 'maincategory';
    protected $primaryKey = 'mcategory_id'; 
    protected $allowedFields = ['mcategory_name','active','created_at','updated_at'];
}


?>