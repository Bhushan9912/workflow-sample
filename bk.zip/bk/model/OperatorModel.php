<?php 
namespace App\Models;

use CodeIgniter\Model;

class OperatorModel extends Model
{
    protected $table = 'operator';
    protected $primaryKey = 'operator_id '; 
    protected $allowedFields = ['operator_name','active','created_at','created_by','updated_at','updated_by','deleted_at','deleted_by'];
}

?>