<?php 
namespace App\Models;

use CodeIgniter\Model;

class RegisterModel extends Model
{
    protected $table = 'Users';
    protected $allowedFields = ['name', 'email', 'password','active','created_at','updated_at'];
}


?>