<?php 
namespace App\Models;

use CodeIgniter\Model;

class RuleActionModel extends Model
{
    protected $table = 'rule_action';
    protected $primaryKey = 'rule_action_id'; 
    protected $allowedFields = ['rule_id','action_id','created_at','created_by'];
}


?>