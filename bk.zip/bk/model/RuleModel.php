<?php 
namespace App\Models;

use CodeIgniter\Model;

class RuleModel extends Model
{
    protected $table = 'rule';
    protected $primaryKey = 'rule_id '; 
    protected $allowedFields = ['work_flow_id','rule_name','expression','operator_id','created_at','created_by'];
}


?>