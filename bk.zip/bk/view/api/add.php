
<?php $this->extend('layouts/master')?>
<?php $this->section('content'); ?>
    <section class="content">
    <div class="container-fluid">
        <div class="row">
          <div class="col-4">
          <div class="card card-info">
              <div class="card-header">
                <h3 class="card-title">All From Control Demo</h3>
              </div>
              <form action="<?php echo site_url('from_control_save');?>" method="post" class="form-horizontal" enctype="multipart/form-data">
              <?php csrf_field() ?>
                <div class="card-body">
                  <div class="form-group">
                    <label for="product_name">Name <small>(Textbox)</small></label>
                    <input type="textbox" class="form-control" id="name" name="name" placeholder="Name">
                  </div>
                  <div class="form-group">
                    <label for="category_id">Select City</label>
                    <select class="form-control" name="city" id="city">
                      <option value="">-Select City-</option>
                      <option value="Nashik">Nashik</option>
                      <option value="Mumbai">Mumbai</option>
                      <option value="Pune">Pune</option>
                     </select>
                  </div>
                  <div class="form-group">
                    <label for="category_id">Education <small>(Checkbox)</small></label><br/>
                    <input type="checkbox"  id="checkboxPrimary1" name="education[]" value="10th"> <strong>10th</strong></div>
                    <input type="checkbox"  id="checkboxPrimary1" name="education[]" value="12th"> <strong>12th</strong>
                    <input type="checkbox"  id="checkboxPrimary1" name="education[]" value="Bsc"> <strong>Bsc</strong>
                    <input type="checkbox"  id="checkboxPrimary1" name="education[]" value="Msc"> <strong>Msc</strong>
                  </div>
                  <div class="form-group">
                    <label for="category_id">Gender <small>(Radio Button)</small></label>
                    <br/><input type="radio"  id="gender" name="gender" value="female"><strong> Female </strong>
                    <input type="radio"  id="gender" name="gender" value="male"><strong> Male </strong>
                  </div>
                  <div class="form-group">
                    <label for="category_id">Image <small>(Textbox)</small></label>
                    <input type="file" class="form-control" id="image" name="image">
                  </div>
                  <div class="form-group">
                    <label for="category_id">Description <small>(Textarea)</small></label>
                    <textarea class="form-control" id="descr" name="descr" row="5"> </textarea>
                  </div>
                </div>
                <div class="card-footer">
                  <button type="submit" class="btn btn-info">Save</button>
               
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- DataTables  & Plugins -->
<?php $this->endSection() ?>