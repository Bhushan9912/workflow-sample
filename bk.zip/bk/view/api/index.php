
<?php $this->extend('layouts/master')?>
<?php $this->section('content'); ?>
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <div class="col-10">
            
                </div>
                <div class="col-2 pull-right">
                <a href="<?php echo site_url('add_'.$url_slug)?>" class="btn  btn-sm btn-primary pull-right"><i class="fa fa-plus"></i> Add</a>
                </div>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="example1" class="table table-bordered table-striped">
                  <thead>
                  <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Main Category</th>
                    <th>Category</th>
                    <th>Image</th>
                     <th>Action</th>
                  </tr>
                  </thead>
                  <tbody>
                  <?php foreach ($product as $key => $value): ?>    
                  <tr>
                    <td><?php echo $key+1 ;?></td>
                    <td><?php echo $value->product_name?></td>
                    <td><?php echo $value->mcategory_name?></td>
                    <td><?php echo $value->category_name?></td>
                    <td><a data-fancybox="gallery" href="<?php echo base_url().'\public\assets\img\product\\'.$value->image;?>"><img src="<?php echo base_url().'\public\assets\img\product\\'.$value->image;?>" height="40" width="40"></a></td>
                    <td>
                       <!--  <a href="<?php echo base_url('PdfController/htmlToPDF') ?>" class="btn btn-sm btn-dange "> -->
                        <a href="<?php echo site_url('').'product_pdf/'.$value->product_id;?>" class="btn btn-sm btn-danger" target="+blank">
                          Download PDF
                        </a>
                        <?php if($value->active=='y') {
                        $checked="checked"; $style="success"; } 
                        else
                        { $checked=""; $style="danger"; 
                        }?>    
                        <input type="checkbox" <?php echo $checked;?> data-toggle="toggle" data-onstyle="success" title="status" 
                        onchange="change_Status(<?php echo $key+1; ?>,<?php echo $value->product_id; ?>);" data-offstyle="danger" 
                        id="<?php echo $key+1;?>_is_active" data-size="small" data-style="slow" >
                    
                        <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#modal-lg">
                      <i class="fas fa-eye" onclick="viewProduct(<?php echo $value->product_id;?>)"></i>
                      </button>
                      <a href="<?php echo site_url('').'edit_product/'.$value->product_id;?>" class="btn-sm btn-primary btn"><i class="fas fa-pencil-alt"></i></a>
                    <!--   <a href="<?php echo site_url('').'product_delete/'.$value->product_id;?>" class="btn-sm btn-danger btn" onclick="confirm(are you sure to delete?);"><i class="fas fa-trash-alt"></i></a></td>
                     -->  
                       <button class="btn-sm btn-danger btn" onclick="delete_product(<?php echo $value->product_id; ?>);"><i class="fas fa-trash-alt"></i></button></td>
                  </tr>
                  <?php endforeach; ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <div class="modal fade" id="modal-lg" style="display: none;" aria-hidden="true">
      <div class="modal-dialog modal-lg">
        <div class="modal-content" id="content">
          
        </div>
      </div>
    </div>  
    <!-- DataTables  & Plugins -->
<script src="<?php echo site_url('public/assets/plugins/datatables/jquery.dataTables.min.js');?>"></script>
<script src="<?php echo site_url('public/assets/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js');?>"></script>
<script src="<?php echo site_url('public/assets/plugins/datatables-responsive/js/dataTables.responsive.min.js');?>"></script>
<script src="<?php echo site_url('public/assets/plugins/datatables-responsive/js/responsive.bootstrap4.min.js');?>"></script>

<script>
  $(function () {
    $("#example1").DataTable({
      "responsive": true, "lengthChange": false, "autoWidth": true,
    });
  });

  function viewProduct(pid)
  {
    var product_id = pid;
    $.ajax({
        url:"<?php echo site_url('').'product_details'?>",
        type:'post',
        data:{id:product_id},
        success:function(data)
        {
          $('#content').html(data);
        }
    });
  }

  function change_Status(id,p_id) 
    {  
      swal({
        title: "Product status",
        text: "Are You sure to change product status",
        icon: "warning",
          buttons: [
            'Cancel',
            'Yes, change it!'
          ],
        }).then(function(isConfirm) {
          if (isConfirm) 
          { 
            var status = $("#"+id+"_is_active").prop('checked');
            var pid = p_id;
             $.ajax({
                  url: "<?php echo site_url('').'product_status'?>",
                  type: 'post',
                  data: {status:status,pid:pid},
                  success: function (data) 
                  {
                    swal("Success", "Product status successfully changed !", "success");
                  }
              });
                
          } else {
               
            var className = $("#"+id+"_is_active").closest('div').prop('className');
           
            if(className == "toggle btn btn-sm slow btn-danger off"){
               $("#"+id+"_is_active").closest('div').removeClass(className);
               $("#"+id+"_is_active").closest('div').addClass('toggle btn btn-success btn-sm slow');
            }else{
              $("#"+id+"_is_active").closest('div').removeClass(className);
               $("#"+id+"_is_active").closest('div').addClass('toggle btn btn-sm slow btn-danger off');
            }
          }
        });
     }

     function delete_product(p_id) 
    {  
      swal({
        title: "Product Delete",
        text: "Are You sure to delete product",
        icon: "error",
          buttons: [
            'Cancel',
            'Yes, change it!'
          ],
        }).then(function(isConfirm) {
            if (isConfirm) 
            { 
              $.ajax({
                    url: "<?php echo site_url('').'product_delete'?>",
                    type: 'post',
                    data: {pid:p_id},
                    success: function (data) 
                    {
                      swal("Success", "Product Deleted successfully.", "success");
                      location.reload();
                    }
                });
                  
            } 
          });
      
     }
</script>
<?php $this->endSection() ?>