
<?php $this->extend('layouts/master')?>
<?php $this->section('content'); ?>
    <section class="content">
    <div class="container-fluid">
        <div class="row">
          <div class="col-4">
          <div class="card card-info">
              <div class="card-header">
                <h3 class="card-title">Add Category</h3>
              </div>
              <form action="<?php echo site_url('category_save');?>" method="post" class="form-horizontal">
              <?php csrf_field() ?>
                <div class="card-body">
                  <div class="form-group">
                    <label for="category_name">Category Name</label>
                    <input type="textbox" class="form-control" id="category_name" name="category_name" placeholder="Category Name">
                  </div>
                </div>
                <div class="card-footer">
                  <button type="submit" class="btn btn-info">Save</button>
                  <a href="<?php echo site_url('/manage_category')?>" class="btn btn-default float-right">Cancel</a>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- DataTables  & Plugins -->
<?php $this->endSection() ?>