
<?php $this->extend('layouts/master')?>
<?php $this->section('content'); ?>
    <section class="content">
    <div class="container-fluid"><br/>
        <div class="row">
          <div class="col-6">
          <div class="card card-info">
              <div class="card-header">
                <h3 class="card-title">Send Mail</h3>
              </div>
              <form action="<?php echo site_url('sendmail');?>" method="post" class="form-horizontal" enctype="multipart/form-data">
              <?php csrf_field() ?>
                <div class="card-body">
                  <div class="form-group">
                    <label for="email">Enter Mail</label>
                    <input type="textbox" class="form-control" id="email" name="email" placeholder="Enter Mail">
                  </div>

                  <div class="form-group">
                    <label for="email">Enter Subject</label>
                    <input type="textbox" class="form-control" id="subject" name="subject" placeholder="Enter Mail">
                  </div>
                
                  <div class="form-group">
                    <label for="category_id">Message Description</label>
                    <textarea class="form-control" id="message" name="message" row="5"> </textarea>
                  </div>
                </div>
                <div class="card-footer">
                  <button type="submit" class="btn btn-info">Send Mail</button>
                 
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- DataTables  & Plugins -->
    <script src="https://cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>
    <script>
                        CKEDITOR.replace( 'message1' );
                </script>
<?php $this->endSection() ?>