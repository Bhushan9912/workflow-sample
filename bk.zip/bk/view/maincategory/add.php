
<?php $this->extend('layouts/master')?>
<?php $this->section('content'); ?>
    <section class="content">
    <div class="container-fluid">
        <div class="row">
          <div class="col-4">
          <div class="card card-info">
              <div class="card-header">
                <h3 class="card-title">Add Main Category</h3>
              </div>
              <form action="<?php echo site_url('main_category_save');?>" method="post" class="form-horizontal">
              <?php csrf_field() ?>
                <div class="card-body">
                  <div class="form-group">
                    <label for="category_name">Main Category Name</label>
                    <input type="textbox" class="form-control" id="mcategory_name" name="mcategory_name" placeholder="Main Category Name">
                  </div>
                </div>
                <div class="card-footer">
                  <button type="submit" class="btn btn-info">Save</button>
                  <a href="<?php echo site_url('/manage_main_category')?>" class="btn btn-default float-right">Cancel</a>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- DataTables  & Plugins -->
<?php $this->endSection() ?>