
<?php $this->extend('layouts/master')?>
<?php $this->section('content'); ?>
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <div class="col-10">
            
                </div>
                <div class="col-2 pull-right">
                <a href="<?php echo site_url('add_main_category')?>" class="btn  btn-sm btn-primary pull-right"><i class="fa fa-plus"></i> Add</a>
                </div>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="example1" class="table table-bordered table-striped">
                  <thead>
                  <tr>
                    <th>#</th>
                    <th>Name</th>
                     <th>Action</th>
                  </tr>
                  </thead>
                  <tbody>
                  <?php foreach ($category as $key => $value): ?>    
                  <tr>
                    <td><?php echo $key+1 ;?></td>
                    <td><?php echo $value['mcategory_name'];?></td>
                    <td>
                    <?php if($value['active']=='y') {
                        $checked="checked"; $style="success"; } 
                        else
                        { $checked=""; $style="danger"; 
                        }?>    
                        <input type="checkbox" <?php echo $checked;?> data-toggle="toggle" data-onstyle="success" title="status" 
                        onchange="change_Status(<?php echo $key+1; ?>,<?php echo $value['mcategory_id'] ?>);" data-offstyle="danger" 
                        id="<?php echo $key+1;?>_is_active" data-size="small" data-style="slow" >
                      <a href="<?php echo site_url('').'edit_main_category/'.$value['mcategory_id'];?>" class="btn-sm btn-primary btn"><i class="fas fa-pencil-alt"></i></a>
                      <a href="<?php echo site_url('').'main_category_delete/'.$value['mcategory_id'];?>" class="btn-sm btn-danger btn"><i class="fas fa-trash-alt"></i></a></td>
                  </tr>
                  <?php endforeach; ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- DataTables  & Plugins -->
<script src="<?php echo site_url('public/assets/plugins/datatables/jquery.dataTables.min.js');?>"></script>
<script src="<?php echo site_url('public/assets/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js');?>"></script>
<script src="<?php echo site_url('public/assets/plugins/datatables-responsive/js/dataTables.responsive.min.js');?>"></script>
<script src="<?php echo site_url('public/assets/plugins/datatables-responsive/js/responsive.bootstrap4.min.js');?>"></script>

<script>
  $(function () {
    $("#example1").DataTable({
      "responsive": true, "lengthChange": false, "autoWidth": true,
    });
  });

  function change_Status(id,p_id) 
    {  
      
      swal({
        title: "main category status",
        text: "Are You sure to change main category status",
        icon: "warning",
          buttons: [
            'Cancel',
            'Yes, change it!'
          ],
         
        }).then(function(isConfirm) {
          if (isConfirm) 
          { 
            var status = $("#"+id+"_is_active").prop('checked');
            var pid = p_id;
             $.ajax({
                  url: "<?php echo site_url('').'main_category_status'?>",
                  type: 'post',
                  data: {status:status,pid:pid},
                  success: function (data) 
                  {
                    swal("Success", "Main category status successfully changed !", "success");
                  }
              });
                
          } else {
               
            var className = $("#"+id+"_is_active").closest('div').prop('className');
           
            if(className == "toggle btn btn-sm slow btn-danger off"){
               $("#"+id+"_is_active").closest('div').removeClass(className);
               $("#"+id+"_is_active").closest('div').addClass('toggle btn btn-success btn-sm slow');
            }else{
              $("#"+id+"_is_active").closest('div').removeClass(className);
               $("#"+id+"_is_active").closest('div').addClass('toggle btn btn-sm slow btn-danger off');
            }
          }
        });


     }

</script>
<?php $this->endSection() ?>