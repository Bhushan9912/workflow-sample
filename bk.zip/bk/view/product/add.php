
<?php $this->extend('layouts/master')?>
<?php $this->section('content'); ?>
    <section class="content">
    <div class="container-fluid">
        <div class="row">
          <div class="col-4">
          <div class="card card-info">
              <div class="card-header">
                <h3 class="card-title">Add Product</h3>
              </div>
              <form action="<?php echo site_url($url_slug.'_save');?>" method="post" class="form-horizontal" enctype="multipart/form-data">
              <?php csrf_field() ?>
                <div class="card-body">
                  <div class="form-group">
                    <label for="product_name">Product Name</label>
                    <input type="textbox" class="form-control" id="product_name" name="product_name" placeholder="Product Name">
                  </div>
                  <div class="form-group">
                    <label for="product_name">Product Price</label>
                    <input type="textbox" class="form-control" id="product_price" name="product_price" placeholder="Product Name">
                  </div>
               
                  <div class="form-group">
                    <label for="category_id">Main Category Name</label>
                    <select class="form-control" name="mcategory_id" id="mcategory_id">
                      <option value="">-Select Main Category-</option>
                      <?php foreach($maincategory as $mcat_value){?>
                      <option value="<?php echo $mcat_value['mcategory_id'];?>"><?php echo $mcat_value['mcategory_name'];?></option>
                      <?php }?>
                    </select>
                  </div>
                  <div class="form-group">
                    <label for="category_id">Category Name</label>
                    <select class="form-control" name="category_id" id="category_id">
                      <option value="">-Select Category-</option>
                      <?php foreach($category as $cat_value){?>
                      <option value="<?php echo $cat_value['category_id'];?>"><?php echo $cat_value['category_name'];?></option>
                      <?php }?>
                    </select>
                  </div>
               
                  <div class="form-group">
                    <label for="category_id">Product Image</label>
                    <input type="file" class="form-control" id="image" name="image" placeholder="Category Name">
                  </div>
                  <div class="form-group">
                    <label for="category_id">Product Description</label>
                    <textarea class="form-control" id="descr" name="descr" row="5"> </textarea>
                  </div>
                </div>
                <div class="card-footer">
                  <button type="submit" class="btn btn-info">Save</button>
                  <a href="<?php echo site_url('/manage_'.$url_slug)?>" class="btn btn-default float-right">Cancel</a>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- DataTables  & Plugins -->
<?php $this->endSection() ?>