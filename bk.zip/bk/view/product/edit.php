
<?php $this->extend('layouts/master')?>
<?php $this->section('content'); ?>
    <section class="content">
    <div class="container-fluid">
        <div class="row">
          <div class="col-4">
          <div class="card card-info">
   
              <div class="card-header">
                <h3 class="card-title">Edit Product</h3>
              </div>
              <form action="<?php echo site_url('product_update');?>" method="post" class="form-horizontal" enctype="multipart/form-data">
              <?php csrf_field() ?>
              <div class="card-body">
                  <div class="form-group">
                    <label for="product_name">Product Name</label>
                    <input type="textbox" class="form-control" id="product_name" name="product_name" placeholder="Product Name" value="<?php echo $row['product_name']?>">
                    <input type="hidden" name="product_id" value="<?php echo $row['product_id']?>">
                  </div>
                  <div class="form-group">
                    <label for="product_name">Product Price</label>
                    <input type="textbox" class="form-control" id="product_price" name="product_price" placeholder="Product Price" value="<?php echo $row['product_price']?>">
                  </div>
                  <div class="form-group">
                    <label for="category_id">Main Category Name</label>
                    <select class="form-control" name="mcategory_id" id="mcategory_id">
                      <option value="">-Select Main Category-</option>
                      <?php foreach($maincategory as $mcat_value){?>
                      <option value="<?php echo $mcat_value['mcategory_id'];?>" <?php if($row['mcategory_id']==$mcat_value['mcategory_id']){ echo "selected";}?>><?php echo $mcat_value['mcategory_name'];?></option>
                      <?php }?>
                    </select>
                  </div>
                  <div class="form-group">
                    <label for="category_id">Category Name</label>
                    <select class="form-control" name="category_id" id="category_id">
                      <option value="">-Select Category-</option>
                      <?php foreach($category as $cat_value){?>
                      <option value="<?php echo $cat_value['category_id'];?>" <?php if($row['category_id']==$cat_value['category_id']){ echo "selected";}?>><?php echo $cat_value['category_name'];?></option>
                      <?php }?>
                    </select>
                  </div>
                  
                  <div class="form-group">                  
                    <label for="category_id">Product Image</label>
                      <div class="input-group mb-3">
                        <input type="file" class="form-control" id="image" name="image" >
                          <div class="input-group-append">
                            <span class="input-group-text">
                            <a data-fancybox="gallery" href="<?php echo base_url().'\public\assets\img\product\\'.$row['image'];?>">
                            <i class="fas fa-eye"></i>
                            </a>
                            </span>
                          </div>
                      </div>
                  </div>
                  <div class="form-group">
                    <label for="category_id">Product Description</label>
                    <textarea class="form-control" id="descr" name="descr" row="5"><?php echo $row['descr'];?></textarea>
                  </div>
                </div>
                <input type="hidden" class="form-control" id="old_image" name="old_image" value="<?php echo $row['image']?>">
                <div class="card-footer">
                  <button type="submit" class="btn btn-info">Update</button>
                  <a href="<?php echo site_url('/manage_product')?>" class="btn btn-default float-right">Cancel</a>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.min.js" integrity="sha512-uURl+ZXMBrF4AwGaWmEetzrd+J5/8NRkWAvJx5sbPSSuOb0bZLqf+tOzniObO00BjHa/dD7gub9oCGMLPQHtQA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.min.css" integrity="sha512-H9jrZiiopUdsLpg94A333EfumgUBpO9MdbxStdeITo+KEIMaNfHNvwyjjDJb+ERPaRS6DpyRlKbvPUasNItRyw==" crossorigin="anonymous" referrerpolicy="no-referrer" />

    <!-- DataTables  & Plugins -->
<?php $this->endSection() ?>