<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Codeigniter 4 PDF Example - positronx.io</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
</head>

<body>
  <div class="container mt-5">
      <div class="row">
        <div class="col-md-12">
          <h2>Demo Product Pdf </h2>
        </div>
      </div>
      <hr/>
      <div class="">
        <div class="col-md-12">
            <h6><b>Product Name : <?php echo ucfirst($product[0]->product_name);?></b></h6>
        </div>  
        <hr/>
        <div class="col-md-12">
             <h6><b>Product category : <?php echo ucfirst($product[0]->category_name);?></b></h6>
        </div>
        <div class="col-md-12">
            <img src="<?php echo base_url().'\public\assets\img\product\\'.$product[0]->image;?>" width="750px" height="400px"></div>
        </div>
        <div class="col-md-12">
            <p class="text-justify"><?php echo $product[0]->descr;?></p>
        </div>
      </div>
  </div<>
</body>

</html>