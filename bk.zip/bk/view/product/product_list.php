<?php $this->extend('layouts/master')?>
<?php $this->section('content'); ?>


<?php if (session()->has('error')) {?>
        <div class="alert alert-danger alert-dismissible fade in" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">×</span>
            </button>
            <strong>Error!</strong> <?=session("error")?>
        </div>
        <?php }?>

        <?php if (session()->has('success')) {?>
            <div class="alert alert-success alert-dismissible fade in" role="alert">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
                <strong>Success!</strong> <?=session("success")?>
            </div>
        <?php }?>
    <section class="content">
      <div class="container-fluid">
        <div class="row" style="padding:10px">            
               <?php foreach ($product as $key => $value): ?>   
                <div class="col-4 mb-5">   
               <form action="<?=base_url('payment')?>" id="<?php echo $value->product_name?>" class="frm" method="POST" >
                    <div class="card" style="width: 26rem;">
                    <img src="<?php echo base_url().'\public\assets\img\product\\'.$value->image;?>" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title"><b><?php echo $value->product_name?></b></h5><br/>
                        <hr/>
                        <input type="hidden" name="product_id" value="<?php echo $value->product_id?>">
                        <p class="card-text"><?php echo substr($value->descr,0,200);?></p>
                        <hr/>
                        <h3 class="card-title"><b>Rs.<?php echo $value->product_price?></b></h3>
                        </div>   
                    </div>
                     <script src="https://checkout.razorpay.com/v1/checkout.js"
                                data-key="<?=env('razorKey')?>"
                                data-amount="<?php echo $value->product_price * 100;?>"
                                data-buttontext="Buy Product"
                                data-name="<?php echo $value->product_name?>"
                                data-description="Sample product Buy "
                                data-image="http://localhost/admin/public/assets/dist/img/AdminLTELogo.png"
                                data-prefill.name="Admin"
                                data-prefill.contact="9834614762"
                                data-prefill.email="admin@gmail.com"
                                data-theme.color="#528FF0">
                        </script>
                 </form>
                 </div>
                 <?php endforeach; ?>
        </div>
      </div>
    </section>
    <style>
  .razorpay-payment-button {
    background-color: purple;
    color: white;
    padding: 10px;
    border-radius: 25px;
    border: 1px;
    align: center;
    text-align: center;
    
    }
</style>
    <!-- DataTables  & Plugins -->
<?php $this->endSection() ?> 
<script>
    $('.razorpay-payment-button').addclass('btn-primary');
</script>
