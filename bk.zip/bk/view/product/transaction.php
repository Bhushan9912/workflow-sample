
<?php $this->extend('layouts/master')?>
<?php $this->section('content'); ?>
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
            
              <!-- /.card-header -->
              <div class="card-body">
                
                <table id="example1" class="table table-bordered table-striped">
                  <thead>
                  <tr>
                    <th>#</th>
                    <th>Product Name</th>
                    <th>Email</th>
                    <th>Contact Number</th>
                    <th>Amount</th>
                    <th>Trnx_id</th>
                    <th>Transaction Date</th>
                    
                  </tr>
                  </thead>
                  <tbody>
                  <?php foreach ($transaction as $key => $value): ?>    
                  <tr>
                    <td><?php echo $key+1 ;?></td>
                    <td><?php echo $value->product_name?></td>
                    <td><?php echo $value->email?></td>
                    <td><?php echo $value->contact?></td>
                    <td>Rs .<?php echo $value->amount/100?></td>
                    <td><?php echo $value->trnx_id?></td>
                    <td><?php echo date('d-m-Y',strtotime($value->transaction_date))?></td>
                    
                  </tr>
                  <?php endforeach; ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
   
    <script src="<?php echo site_url('public/assets/plugins/datatables/jquery.dataTables.min.js');?>"></script>
<script src="<?php echo site_url('public/assets/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js');?>"></script>
<script src="<?php echo site_url('public/assets/plugins/datatables-responsive/js/dataTables.responsive.min.js');?>"></script>
<script src="<?php echo site_url('public/assets/plugins/datatables-responsive/js/responsive.bootstrap4.min.js');?>"></script>

<script>
  $(function () {
    $("#example1").DataTable({
      "responsive": true, "lengthChange": false, "autoWidth": true,
    });
  });
  </script>
<?php $this->endSection() ?>