<?php //echo $product[0]->product_name;exit;?>
<div class="modal-header">
    <h6 class="modal-title"><b>Product Name : <?php echo ucfirst($product[0]->product_name);?></b></h6>
    <hr/>
    <h6 class="modal-title"><b>Product category : <?php echo ucfirst($product[0]->category_name);?></b></h6>
    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">×</span>
    </button>
</div>
<div class="modal-body">
    <div class="col-md-12">
        <img src="<?php echo base_url().'\public\assets\img\product\\'.$product[0]->image;?>" width="750px" height="400px"></div>
    </div>
    <div class="col-md-12">
        <p class="text-justify"><?php echo $product[0]->descr;?></p>
    </div>
</div>
